/*  1:   */ package gnu.io;
/*  2:   */ 
/*  3:   */ public class UnsupportedCommOperationException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   public UnsupportedCommOperationException() {}
/*  7:   */   
/*  8:   */   public UnsupportedCommOperationException(String paramString)
/*  9:   */   {
/* 10:85 */     super(paramString);
/* 11:   */   }
/* 12:   */ }


/* Location:           F:\workspace_java\comemso_reichweite_analyse\impl\Application\CAN-Oscilloscope\CAN-Oscilloscope 2.0\lib\RXTXcomm.jar
 * Qualified Name:     gnu.io.UnsupportedCommOperationException
 * JD-Core Version:    0.7.0.1
 */