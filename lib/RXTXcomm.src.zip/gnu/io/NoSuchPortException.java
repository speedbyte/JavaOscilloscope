/*  1:   */ package gnu.io;
/*  2:   */ 
/*  3:   */ public class NoSuchPortException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   NoSuchPortException(String paramString)
/*  7:   */   {
/*  8:72 */     super(paramString);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public NoSuchPortException() {}
/* 12:   */ }


/* Location:           F:\workspace_java\comemso_reichweite_analyse\impl\Application\CAN-Oscilloscope\CAN-Oscilloscope 2.0\lib\RXTXcomm.jar
 * Qualified Name:     gnu.io.NoSuchPortException
 * JD-Core Version:    0.7.0.1
 */